#include "SceneObject.h"
#include "checkML.h"

#pragma once
using namespace std;

class Enemy : public SceneObject
{

};


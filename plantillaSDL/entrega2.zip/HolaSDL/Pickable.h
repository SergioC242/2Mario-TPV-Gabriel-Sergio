#include "SceneObject.h"
#include "checkML.h"

#pragma once
using namespace std;

class Pickable : public SceneObject
{
public:
	void act();
};

